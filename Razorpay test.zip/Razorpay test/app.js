const express = require("express");
const app = express();
const bodyParser=require("body-parser");
const port = 4000;
const Razorpay =require("razorpay");
const cors = require("cors");
app.use(bodyParser.urlencoded({ extended: true }));


app.use(express.json());
app.use(cors())
app.get("/",(req,res)=>{
    res.sendFile(__dirname + '/index.html');

    
});

app.post("/payment", async(req, res)=>{

    let {amount} = req.body;
    var instance = new Razorpay({ key_id: 'rzp_test_zEbp1dOcfC8PeK', key_secret: 'JHX3ymWnrImZRqVRPO6Rpwp4' });

    let order = await instance.orders.create({
        amount: amount*100,
        currency: "INR",
        receipt: "receipt#1",
      
    });
     
    res.status(201).json({
            success : true,
            order,
            amount,

    });
});

app.listen(port, () =>{
    console.log(`Server is running on port ${port}`);
});